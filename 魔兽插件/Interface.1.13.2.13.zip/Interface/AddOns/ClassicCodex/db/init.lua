CodexDB = {
  ["items"] = {},
  ["meta"] = {},
  ["objects"] = {},
  ["professions"] = {},
  ["quests"] = {},
  ["refloot"] = {},
  ["units"] = {},
  ["zones"] = {},
}
