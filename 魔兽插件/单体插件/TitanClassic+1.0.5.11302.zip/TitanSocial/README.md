# TitanSocial
TitanSocial is an interface add-on for World of Warcraft that displays information about friends and guild members.

You can download the source here, or at [curse](http://www.curse.com/addons/wow/titanpanel-social)!
