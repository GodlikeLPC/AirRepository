## LibQuestXP - Changelog

**1.0.7**

- No longer loads on Retail

**1.0.6**

- Updated quest XP data

**1.0.5**

- Added more quests

**1.0.4**

- Return 0 as adjusted XP if the character is level 60

**1.0.3**

- Add LibQuestXP.xml for easier embedding

**1.0.2**

- Change XP calculation math

**1.0.1**

- Initial release
