#Songbird for WoW:Classic
Songflower timers shared with your friends in the guild and raid group!

 

The addon is still in it's very early stages, so I gladly take any feedback you can give! I'll be improving the addon in the weeks to come.

 

#What it does
This addon aims to make it easier to time your Songflower buffs.

In it's most simple state, it's lists the spawn points of all Songflowers.

 

When you pick a Songflower, a timer will be added (25 minutes) for the next spawn. At the same time, this timer will be broadcast to your guild and raid members, so that they can see the same timer you do.

 

#Commands
/songbird show - Shows the icons and timers on the world map if they are hidden
/songbird hide - Hides the icons and timers on the world map if they are shown

@Netzone <FADE> - Earthshaker
