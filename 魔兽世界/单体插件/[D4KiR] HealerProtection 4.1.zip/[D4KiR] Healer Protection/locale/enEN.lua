-- enEN English

function D4_HP.Lang_enEN()
	lang.aggro = "AGGRO"
	lang.showaggrochat = "AGGRO Chat-Message"
	lang.showaggroemote = "AGGRO Emote"

	lang.outofmana = "Out of Mana"
	lang.showoomchat = "OOM Chat-Message"
	lang.showoomemote = "OOM Emote"

	lang.nearoutofmana = "Near out of Mana"
	lang.shownearoomchat = "Near OOM Chat-Message"
	lang.shownearoomemote = "Near OOM Emote"

	lang.youhaveaggro = "You have AGGRO"
	lang.ihaveaggro = "I have AGGRO"

	lang.underhealthprintmessage = "If under VALUE% Health, print message"
	lang.undermanaprintmessage = "If under VALUE% Mana, print message"

	lang.xmana = "MANA% Mana"

	lang.showlocchat = "Loss of control Chat-Nachricht"
	lang.showlocemote = "Loss of control Emote"
	lang.loctext = "ART (For X seconds)"

	lang.prefix = "Prefix"
	lang.suffix = "Suffix"
end
