-- deDE German Deutsch

function D4_HP.Lang_deDE()
	lang.aggro = "AGGRO"
	lang.showaggrochat = "AGGRO Chat-Nachricht"
	lang.showaggroemote = "AGGRO Emote"

	lang.outofmana = "Mana leer"
	lang.showoomchat = "Mana leer Chat-Nachricht"
	lang.showoomemote = "Mana leer Emote"

	lang.nearoutofmana = "Mana fast leer"
	lang.shownearoomchat = "Mana fast leer Chat-Nachricht"
	lang.shownearoomemote = "Mana fast leer Emote"

	lang.youhaveaggro = "Du hast AGGRO"
	lang.ihaveaggro = "Ich habe AGGRO"

	lang.underhealthprintmessage = "Wenn unter VALUE% Gesundheit, dann Nachricht senden"
	lang.undermanaprintmessage = "Wenn unter VALUE% Mana, dann Nachricht senden"

	lang.xmana = "MANA% Mana"

	lang.showlocchat = "Kontrollverlust Chat-Nachricht"
	lang.showlocemote = "Kontrollverlust Emote"
	lang.loctext = "ART (Für X Sekunden)"

	lang.prefix = "Präfix"
	lang.suffix = "Suffix"
end
