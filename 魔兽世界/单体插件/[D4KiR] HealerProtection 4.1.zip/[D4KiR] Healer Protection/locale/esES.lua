-- ruRU Russian

function D4_HP.Lang_esES()
	lang.aggro = "AGGRO"
	lang.showaggrochat = "AGGRO Mensaje de chat"
	lang.showaggroemote = "AGGRO Emote"

	lang.outofmana = "Sin Mana"
	lang.showoomchat = "Sin Mana Mensaje de chat"
	lang.showoomemote = "Sin Mana Emote"

	lang.nearoutofmana = "Casi sin Mana"
	lang.shownearoomchat = "Casi sin Mana Mensaje de chat"
	lang.shownearoomemote = "Casi sin Mana Emote"

	lang.youhaveaggro = "Tienes AGGRO"
	lang.ihaveaggro = "Tengo AGGRO"

	lang.underhealthprintmessage = "Si estas por debajo de VALUE% de vida, escribir mensaje"
	lang.undermanaprintmessage = "Si estas por debajo de VALUE% de mana, escribir mensaje"

	lang.xmana = "MANA% Mana"

	lang.showlocchat = "Perdida de control Mensaje de chat"
	lang.showlocemote = "Perdida de control Emote"
	lang.loctext = "ART (Durante X segundos)"

	lang.prefix = "Prefijo"
	lang.suffix = "Sufijo"
end
