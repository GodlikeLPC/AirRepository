-- zhCN Simplified Chinese

function D4_HP.Lang_zhCN()
	lang.aggro = "仇恨"
	lang.showaggrochat = "聊天框信息-仇恨"
	lang.showaggroemote = "表情-仇恨"

	lang.outofmana = "OOM(空蓝)"
	lang.showoomchat = "聊天框信息-OOM(空蓝)"
	lang.showoomemote = "表情-OOM(空蓝)"

	lang.nearoutofmana = "NOOM(缺蓝)"
	lang.shownearoomchat = "聊天框信息-NOOM(缺蓝)"
	lang.shownearoomemote = "表情-OOM(缺蓝)"

	lang.youhaveaggro = "你获得仇恨!!!"
	lang.ihaveaggro = "注意!我被盯上了!!!"

	lang.underhealthprintmessage = "如果低于 VALUE% 血量就打印聊天框信息"
	lang.undermanaprintmessage = "如果低于 VALUE% 法力值就打印聊天框信息"

	lang.xmana = "MANA% 法力值"

	lang.showlocchat = "控制技能CC-聊天框信息"
	lang.showlocemote = "表情-控制技能CC"
	lang.loctext = "我中了控制技了 (X 秒)"

	lang.prefix = "前缀"
	lang.suffix = "后缀"
end
