-- frFR French

function D4_HP.Lang_frFR()
	lang.aggro = "AGGRO"
	lang.showaggrochat = "AGGRO Message dans le Chat"
	lang.showaggroemote = "AGGRO Emote"

	lang.outofmana = "Plus de Mana"
	lang.showoomchat = "Plus de Mana Chat-Message"
	lang.showoomemote = "OOM Emote"

	lang.nearoutofmana = "Mana faible"
	lang.shownearoomchat = "Presque plus de Mana"
	lang.shownearoomemote = "Presque OOM Emote"

	lang.youhaveaggro = "Vous avez AGGRO"
	lang.ihaveaggro = "AGGRO sur moi"

	lang.underhealthprintmessage = "Si vous êtes sous VALUE% de santé, afficher le message"
	lang.undermanaprintmessage = "Si vous êtes sous VALUE% de mana, afficher le message"

	lang.xmana = "MANA% Mana"

	lang.showlocchat = "Perte de contrôle Message dans le Chat"
	lang.showlocemote = "Perte de contrôle Emote"
	lang.loctext = "ART (Soin dispo dans X secondes)"

	lang.prefix = "Préfixe"
	lang.suffix = "Suffixe"
end
