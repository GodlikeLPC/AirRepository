-- ruRU Russian

function D4_HP.Lang_ruRU()
	lang.aggro = "АГРО"
	lang.showaggrochat = "Сообщение в чате об АГРО"
	lang.showaggroemote = "АГРО/эмоция"

	lang.outofmana = "НЕТ МАНЫ"
	lang.showoomchat = "Сообщение в чат, когда НЕТ МАНЫ"
	lang.showoomemote = "НЕТ МАНЫ/эмоция"

	lang.nearoutofmana = "Почти нет Маны"
	lang.shownearoomchat = "Сообщение в чате, когда почти нет Маны"
	lang.shownearoomemote = "Почти нет Маны/эмоция"

	lang.youhaveaggro = "На вас АГРО"
	lang.ihaveaggro = "На мне АГРО"

	lang.underhealthprintmessage = "Сообщение в чат, если Здоровье упадет ниже VALUE%"
	lang.undermanaprintmessage = "Сообщение в чат, если Мана упадет ниже VALUE%"

	lang.xmana = "MANA% Маны"

	lang.showlocchat = "Сообщение в чате, когда потерян контроль"
	lang.showlocemote = "Потеря контроля/эмоция"
	lang.loctext = "ART (на X секунд)"

	lang.prefix = "Префикс"
	lang.suffix = "Суффикс"
end
