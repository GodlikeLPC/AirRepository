Auctionator.Constants.Rarity = {
  UNCOMMON = 2,
  RARE = 3,
  EPIC = 4
}