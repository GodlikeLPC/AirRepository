Auctionator.Constants.DisenchantingMatMapping = {
  [ Auctionator.Constants.DisenchantMats.LESSER_CEL ] = Auctionator.Constants.DisenchantMats.GREATER_CEL,
  [ Auctionator.Constants.DisenchantMats.LESSER_COSMIC ] = Auctionator.Constants.DisenchantMats.GREATER_COSMIC,
  [ Auctionator.Constants.DisenchantMats.LESSER_PLANAR ] = Auctionator.Constants.DisenchantMats.GREATER_PLANAR
}