-- Contributors: Gotxiko@GitHub

local _, addonTable = ...
local L = addonTable.L

-- Lua
local _G = getfenv(0)

-- Mine
-- These rely on custom strings
L["YOU_LOST_RED"] = "|cffdc4436" .. L["YOU_LOST"] .. "|r"
