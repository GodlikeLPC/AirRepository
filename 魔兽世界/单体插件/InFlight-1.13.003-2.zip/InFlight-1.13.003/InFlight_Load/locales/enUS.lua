local L = LibStub("AceLocale-3.0"):NewLocale("InFlight", "enUS", true)
if not L then return end

L["Nighthaven"] = true
L["NighthavenGossipA"] = "I'd like to fly to Rut'theran Village"
L["NighthavenGossipH"] = "I'd like to fly to Thunder Bluff"
L["Return"] = true
L["Rut'theran Village"] = true
L["Stormwind City"] = true
L["StormwindCityGossip"] = "I'd like to take a flight around Stormwind Harbor"
L["Thunder Bluff"] = true
