local L = LibStub("AceLocale-3.0"):NewLocale("InFlight", "esMX")
if not L then return end

L["Nighthaven"] = "Amparo de la Noche"
L["NighthavenGossipA"] = "Me gustaría volar a Aldea Rut'theran"
L["NighthavenGossipH"] = "Me gustaría volar a Cima del Trueno"
L["Return"] = "Regresar"
L["Rut'theran Village"] = "Aldea Rut'theran"
L["Stormwind City"] = "Ciudad de Ventormenta"
L["StormwindCityGossip"] = "Me gustaría volar alrededor del Puerto de Ventormenta"
L["Thunder Bluff"] = "Cima del Trueno"
