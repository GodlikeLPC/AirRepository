local L = LibStub("AceLocale-3.0"):NewLocale("InFlight", "zhTW")
if not L then return end

L["Nighthaven"] = "永夜港"
L["NighthavenGossipA"] = "我想飛往魯瑟蘭村"
L["NighthavenGossipH"] = "我想飛往雷霆崖"
L["Return"] = "回來"
L["Rut'theran Village"] = "魯瑟蘭村"
L["Stormwind City"] = "暴風城"
L["StormwindCityGossip"] = "我想要繞著暴風港飛一趟"
L["Thunder Bluff"] = "雷霆崖"
