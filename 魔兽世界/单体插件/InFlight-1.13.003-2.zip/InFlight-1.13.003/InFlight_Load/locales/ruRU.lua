local L = LibStub("AceLocale-3.0"):NewLocale("InFlight", "ruRU")
if not L then return end

L["Nighthaven"] = "Ночная Гавань"
L["NighthavenGossipA"] = "Я бы хотел отправиться в деревню Рут'теран"
L["NighthavenGossipH"] = "Мне хотелось бы слетать в Громовой Утес"
L["Return"] = "Возвращение"
L["Rut'theran Village"] = "Деревня Рут'теран"
L["Stormwind City"] = "Штормград"
L["StormwindCityGossip"] = "Я хочу полетать над портом Штормграда"
L["Thunder Bluff"] = "Громовой Утес"
