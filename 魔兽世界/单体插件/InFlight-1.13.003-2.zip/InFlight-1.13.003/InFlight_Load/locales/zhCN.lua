local L = LibStub("AceLocale-3.0"):NewLocale("InFlight", "zhCN")
if not L then return end

L["Nighthaven"] = "永夜港"
L["NighthavenGossipA"] = "我想飞往鲁瑟兰村"
L["NighthavenGossipH"] = "我想飞往雷霆崖"
L["Return"] = "回来"
L["Rut'theran Village"] = "鲁瑟兰村"
L["Stormwind City"] = "暴风城"
L["StormwindCityGossip"] = "我要绕暴风城港口游览一圈"
L["Thunder Bluff"] = "雷霆崖"
