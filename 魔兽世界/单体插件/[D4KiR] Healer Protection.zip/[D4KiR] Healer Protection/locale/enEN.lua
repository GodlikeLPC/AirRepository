-- enEN English

function D4_HP.Lang_enEN()
	lang.aggro = "仇恨过高"
	lang.showaggrochat = "仇恨过高聊天消息"
	lang.showaggroemote = "仇恨过高表情"

	lang.outofmana = "法力耗尽"
	lang.showoomchat = "法力耗尽聊天消息"
	lang.showoomemote = "法力耗尽表情"

	lang.nearoutofmana = "我需要更多法力"
	lang.shownearoomchat = "我需要更多法力聊天消息"
	lang.shownearoomemote = "我需要更多法力表情"

	lang.youhaveaggro = "我仇恨过高，注意保护"
	lang.ihaveaggro = "我仇恨过高，注意保护"

	lang.underhealthprintmessage = "如果低于 VALUE% 生命值, 发出消息"
	lang.undermanaprintmessage = "如果低于 VALUE% 法力值, 发出消息"

	lang.xmana = "MANA% 法力值"

	lang.showlocchat = "被控制发出消息"
	lang.showlocemote = "被控制表情"
	lang.loctext = "被控制(还有X秒)"

	lang.prefix = "前缀"
	lang.suffix = "后缀"
end
